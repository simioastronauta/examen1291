#!/usr/bin/python3
import tkinter as tk
from tkinter import ttk

ventana = tk.Tk()
imagen = tk.PhotoImage(file="betis_icono.png")

botono = ttk.Button(ventana, image=imagen)
botono.pack()

ventana.mainloop()